# ImGui OpenGL2 Kiero Hook
Universal ImGui implementation through OpenGL2 Hook using Kiero based on rdbo's ImGui DirectX 11 Kiero Hook.
<h2>Kiero</h2>
<p>You can find Kiero's official repository <a href="https://github.com/Rebzzel/kiero">here</a>
<h2>ImGui DirectX 11 Kiero Hook</h2>
<p>You can find rdbo's official repository <a href="https://github.com/rdbo/ImGui-DirectX-11-Kiero-Hook">here</a>
<h2>Special thanks</h2>
<p>Sleepyut for helping me with the context rendering issue