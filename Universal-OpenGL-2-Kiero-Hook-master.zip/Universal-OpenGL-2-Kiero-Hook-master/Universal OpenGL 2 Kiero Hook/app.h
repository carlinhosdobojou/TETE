#pragma once

namespace app
{
    void initializeImGui();
    void renderImGui();
    void initializeHook();
}